/**
 * Created by GUNDAM on 8/3/17.
 */
import Vue from 'vue'
export default new Vue();